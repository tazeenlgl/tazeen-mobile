import 'package:flutter/material.dart';

import '../../../app/theme/colors.dart';
import '../../../app/theme/spacing.dart';

class CustomerHomePage extends StatelessWidget {
  const CustomerHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TazeenColors.background,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                TazeenSpacing.lg,
                TazeenSpacing.md,
                TazeenSpacing.lg,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: _Header(),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                TazeenSpacing.lg,
                TazeenSpacing.xl,
                TazeenSpacing.lg,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: _Greeting(),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                TazeenSpacing.lg,
                TazeenSpacing.xl,
                TazeenSpacing.lg,
                TazeenSpacing.md,
              ),
              sliver: SliverToBoxAdapter(
                child: _HeroBanner(),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                TazeenSpacing.lg,
                TazeenSpacing.md,
                TazeenSpacing.lg,
                TazeenSpacing.md,
              ),
              sliver: SliverToBoxAdapter(
                child: _GameTeaserCard(),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.only(
                top: TazeenSpacing.md,
                bottom: TazeenSpacing.xxl,
              ),
              sliver: SliverToBoxAdapter(
                child: SizedBox(
                  height: 132,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(
                      horizontal: TazeenSpacing.lg,
                    ),
                    itemCount: 2,
                    separatorBuilder: (context, index) =>
                        const SizedBox(width: TazeenSpacing.md),
                    itemBuilder: (context, index) => const _OfferBanner(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'TAZEEN',
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.w800,
              letterSpacing: 2.4,
              color: TazeenColors.primary,
            ),
          ),
        ),
        _HeaderButton(
          icon: Icons.search_rounded,
          onTap: () {},
        ),
        const SizedBox(width: TazeenSpacing.sm),
        _HeaderButton(
          icon: Icons.notifications_none_rounded,
          showBadge: true,
          onTap: () {},
        ),
      ],
    );
  }
}

class _HeaderButton extends StatelessWidget {
  const _HeaderButton({
    required this.icon,
    required this.onTap,
    this.showBadge = false,
  });

  final IconData icon;
  final VoidCallback onTap;
  final bool showBadge;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: TazeenColors.surface,
          shape: const CircleBorder(),
          child: InkWell(
            onTap: onTap,
            customBorder: const CircleBorder(),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: TazeenColors.border,
                ),
              ),
              child: Icon(
                icon,
                size: 21,
                color: TazeenColors.text,
              ),
            ),
          ),
        ),
        if (showBadge)
          Positioned(
            top: 1,
            right: 1,
            child: Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: TazeenColors.primary,
                shape: BoxShape.circle,
                border: Border.all(
                  color: TazeenColors.surface,
                  width: 1.5,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _Greeting extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Good morning, Priya',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: TazeenColors.text,
                fontWeight: FontWeight.w700,
                height: 1.1,
              ),
        ),
        const SizedBox(height: TazeenSpacing.xs),
        Text(
          'Discover something beautiful today.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: TazeenColors.textSecondary,
              ),
        ),
      ],
    );
  }
}

class _HeroBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.5,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      TazeenColors.primary,
                      TazeenColors.primaryDark,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: TazeenSpacing.xl,
              right: TazeenSpacing.xl,
              bottom: TazeenSpacing.xl,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'NEW ARRIVALS',
                    style: TextStyle(
                      color: TazeenColors.primaryLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: TazeenSpacing.xs),
                  const Text(
                    'The Autumn Edit',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OfferBanner extends StatelessWidget {
  const _OfferBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 168,
      padding: const EdgeInsets.all(TazeenSpacing.lg),
      decoration: BoxDecoration(
        color: TazeenColors.surfaceSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: TazeenColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(
            Icons.local_offer_rounded,
            color: TazeenColors.primary,
            size: 22,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Special Offer',
                style: TextStyle(
                  color: TazeenColors.text,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: TazeenSpacing.xs),
              Text(
                'Curated for you',
                style: TextStyle(
                  color: TazeenColors.textSecondary,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _GameTeaserCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(TazeenSpacing.lg),
      decoration: BoxDecoration(
        color: TazeenColors.primaryLight,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: TazeenColors.primary,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.sports_esports_rounded,
              color: Colors.white,
              size: 26,
            ),
          ),
          const SizedBox(width: TazeenSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'PLAY & WIN',
                  style: TextStyle(
                    color: TazeenColors.primary,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "Try today's target",
                  style: TextStyle(
                    color: TazeenColors.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: TazeenSpacing.md),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: TazeenSpacing.md,
              vertical: TazeenSpacing.sm,
            ),
            decoration: BoxDecoration(
              color: TazeenColors.primary,
              borderRadius: BorderRadius.circular(999),
            ),
            child: const Text(
              'PLAY NOW',
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
