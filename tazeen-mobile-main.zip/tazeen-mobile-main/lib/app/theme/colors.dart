import 'package:flutter/material.dart';

abstract final class TazeenColors {
  static const primary = Color(0xFF5B277A);
  static const primaryDark = Color(0xFF431C5B);
  static const primaryLight = Color(0xFFEDE3F2);

  static const background = Color(0xFFFCFAFD);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceSoft = Color(0xFFF7F1F9);

  static const text = Color(0xFF241D26);
  static const textSecondary = Color(0xFF756D78);
  static const textMuted = Color(0xFFA59DA8);

  static const border = Color(0xFFE8E1EA);

  static const success = Color(0xFF3D8058);
  static const warning = Color(0xFFB77A22);
  static const error = Color(0xFFB94A48);

  static const white = Colors.white;
  static const black = Colors.black;
}
