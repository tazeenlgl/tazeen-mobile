import 'package:flutter/material.dart';
import 'colors.dart';
import 'typography.dart';

abstract final class TazeenTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: TazeenColors.primary,
      brightness: Brightness.light,
    ).copyWith(
      primary: TazeenColors.primary,
      onPrimary: Colors.white,
      secondary: TazeenColors.primary,
      surface: TazeenColors.surface,
      error: TazeenColors.error,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: TazeenColors.background,
      fontFamily: 'Roboto',

      textTheme: const TextTheme(
        titleLarge: TazeenTypography.titleLarge,
        titleMedium: TazeenTypography.titleMedium,
        bodyLarge: TazeenTypography.bodyLarge,
        bodyMedium: TazeenTypography.bodyMedium,
        labelLarge: TazeenTypography.labelLarge,
        labelSmall: TazeenTypography.caption,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor: TazeenColors.background,
        foregroundColor: TazeenColors.text,
        elevation: 0,
        centerTitle: false,
      ),

      cardTheme: CardThemeData(
        color: TazeenColors.surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: TazeenColors.border),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: TazeenColors.surface,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: TazeenColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: TazeenColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: TazeenColors.primary,
            width: 1.5,
          ),
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: TazeenColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: TazeenColors.primary,
          minimumSize: const Size(double.infinity, 52),
          side: const BorderSide(color: TazeenColors.primary),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),

      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: TazeenColors.surface,
        indicatorColor: TazeenColors.primaryLight,
        elevation: 0,
        labelTextStyle: WidgetStateProperty.resolveWith(
          (states) => TextStyle(
            fontSize: 12,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w600
                : FontWeight.w400,
            color: states.contains(WidgetState.selected)
                ? TazeenColors.primary
                : TazeenColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
