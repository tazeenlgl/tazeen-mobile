import 'package:flutter/material.dart';
import 'app/theme/theme.dart';
import 'features/customer/customer_app_shell.dart';

void main() {
  runApp(const TazeenApp());
}

class TazeenApp extends StatelessWidget {
  const TazeenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tazeen',
      debugShowCheckedModeBanner: false,
      theme: TazeenTheme.light(),
      home: const CustomerAppShell(),
    );
  }
}

