package com.example.tazeen_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
